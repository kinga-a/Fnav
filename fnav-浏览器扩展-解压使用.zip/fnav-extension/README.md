# Fnav Bookmark Manager

为 [Fnav](https://github.com/kinga-a/Fnav) 项目创建的 Chrome/Edge 浏览器扩展程序，支持在扩展中查看和保存书签。

## ✨ 功能

- **查看书签** - 在扩展 popup 中浏览所有书签
- **搜索书签** - 快速搜索书签标题、URL 或描述
- **分类筛选** - 按分类筛选书签
- **保存书签** - 一键保存当前页面或自定义书签到 Fnav
- **配置管理** - 轻松配置 Fnav 服务器地址和密码
- **打开链接** - 点击书签直接打开
- **复制链接** - 一键复制书签 URL
- **分类缓存** - 5 分钟内不重复请求分类数据

## 📦 安装

### 开发者模式安装

1. 克隆或下载此仓库
2. 打开 Chrome/Edge 浏览器，进入扩展管理页面：
   - Chrome: `chrome://extensions/`
   - Edge: `edge://extensions/`
3. 开启「开发者模式」
4. 点击「加载已解压的扩展程序」
5. 选择 `fnav-extension` 文件夹

## ⚙️ 配置

首次使用需要配置 Fnav 信息：

1. 点击扩展图标打开 popup
2. 切换到「设置」标签页
3. 填写以下信息：
   - **Fnav 域名**: 您的 Fnav 部署地址（不含 http(s)://），例如：`nav.example.com`
   - **部署平台**: 选择 EdgeOne 或 Cloudflare
   - **访问密码**: 部署时设置的 PASSWORD 环境变量
4. 点击「测试连接」验证配置
5. 验证成功后点击「保存配置」

## 🚀 使用

### 查看书签

1. 打开扩展 popup
2. 自动加载并显示所有书签
3. 使用搜索框搜索书签
4. 使用分类下拉框筛选特定分类
5. 点击书签打开链接，或使用右侧按钮复制/删除

### 保存书签

1. 浏览到要保存的网页
2. 打开扩展 popup
3. 切换到「保存书签」标签页
4. 选择保存类型：
   - **当前页面**: 自动填充当前页面的标题和 URL
   - **自定义**: 手动输入标题、URL 和描述
5. 选择目标分类
6. 点击「保存书签」

### 净化链接

在「保存书签」标签页，点击「净化链接」按钮可以去除 URL 中的追踪参数，保留干净的链接。

## 🔧 API 接口

本扩展与 Fnav 的以下 API 接口交互：

- **GET /api/storage?getConfig=true&readOnly=true** - 获取分类和书签列表
- **POST /api/link** - 保存新书签

## 📝 注意事项

1. **CORS 配置**: 如果扩展无法连接到 Fnav，请在 Fnav 部署环境中设置 `ALLOWED_ORIGIN` 环境变量，允许扩展的 origin。
2. **权限要求**: 扩展需要 `activeTab` 权限获取当前页面信息，需要 `storage` 权限保存配置。
3. **浏览器兼容性**: 支持 Chrome 88+ 和 Edge 88+（Manifest V3）。

## 🛠️ 开发

项目结构：
```
fnav-extension/
├── manifest.json       # 扩展配置文件
├── popup.html         # Popup 界面
├── popup.css          # Popup 样式
├── popup.js           # Popup 逻辑
├── background.js      # Service Worker
└── icons/             # 扩展图标
    ├── icon16.png
    ├── icon32.png
    ├── icon48.png
    └── icon128.png
```

## 📄 License

MIT License - 基于 [eallion/chrome-extension-favorite](https://github.com/eallion/chrome-extension-favorite) 二次开发。

## 🙏 致谢

- [Fnav](https://github.com/kinga-a/Fnav) - 书签管理应用
- [eallion/chrome-extension-favorite](https://github.com/eallion/chrome-extension-favorite) - 参考的 Chrome 扩展
